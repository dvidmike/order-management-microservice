# Order Microservice

A Spring Boot microservice for managing orders with RESTful APIs, JPA data persistence, and containerization support.

## Features

### Core Business Features
- **CRUD Operations**: Create, read, update, and delete orders
- **Order Status Management**: Track orders through different statuses (PENDING, CONFIRMED, PROCESSING, SHIPPED, DELIVERED, CANCELLED)
- **Customer-based Filtering**: Retrieve orders by customer name
- **Status-based Filtering**: Filter orders by their current status
- **Order Statistics**: Get count of orders by status
- **Business Rule Validation**: Comprehensive quantity, price, and total value limits
- **Status Transition Rules**: Enforced workflow with proper state management

### Technical Features
- **Input Validation**: Bean Validation with custom validators
- **Error Handling**: Global exception handling with proper HTTP status codes and detailed error responses
- **Health Checks**: Spring Boot Actuator endpoints for monitoring and observability
- **Database Integration**: H2 in-memory database with JPA/Hibernate for development
- **Containerization**: Docker support with optimized multi-stage builds
- **Audit Trail**: Automatic timestamp tracking for all operations

### Testing & Quality Assurance
- **Comprehensive Test Suite**: 63+ tests covering unit, integration, and E2E scenarios
- **High Test Coverage**: 80%+ line coverage and 75%+ branch coverage with JaCoCo
- **Multiple Test Layers**: Entity, Repository, Service, Controller, and E2E testing
- **Business Rule Testing**: Complete validation of all business logic and edge cases
- **Performance Testing**: Concurrent operation testing for thread safety
- **HTML Test Reports**: Visual test reporting with Maven Surefire Report Plugin

## Technology Stack

### Core Technologies
- **Java 17** - Latest LTS version providing modern language features, improved performance, and long-term support
- **Spring Boot 3.2.0** - Industry-standard framework for rapid microservice development with embedded server and auto-configuration
- **Spring Data JPA** - Simplifies data access layer with repository abstraction and reduces boilerplate code
- **Spring Web** - Provides RESTful web services capabilities with built-in validation and serialization
- **Spring Boot Actuator** - Production-ready features for monitoring, health checks, and operational insights
- **H2 Database** - Lightweight in-memory database perfect for development and testing environments
- **Maven** - Build automation tool with extensive plugin ecosystem and dependency management
- **Docker** - Container platform enabling consistent deployment across environments

### Testing & Quality Technologies
- **JUnit 5** - Modern testing framework with improved assertions and parameterized testing
- **Mockito** - Powerful mocking framework for unit testing with Java 23 compatibility
- **Spring Boot Test** - Comprehensive testing support with test slices and context management
- **TestContainers** - Integration testing with real database instances
- **JaCoCo** - Code coverage analysis with configurable thresholds (80% line, 75% branch)
- **Maven Surefire Plugin** - Test execution and HTML report generation
- **Maven Site Plugin** - Comprehensive project documentation and reporting

### Development & DevOps Tools
- **VS Code Tasks** - Integrated build, test, and deployment automation
- **Docker Compose** - Multi-container application orchestration
- **Spring Boot DevTools** - Development-time enhancements and hot reloading
- **Actuator Health Checks** - Kubernetes-ready health and readiness probes

### Technology Rationale

**Why Spring Boot?**
- Rapid development with sensible defaults and auto-configuration
- Extensive ecosystem and community support
- Production-ready features out of the box (Actuator, embedded server)
- Seamless cloud-native deployment capabilitie

**Why JPA/Hibernate?**
- Database vendor independence through abstraction
- Automatic SQL generation and optimization
- Built-in caching and lazy loading capabilities
- Seamless integration with Spring's transaction management

## Architecture Considerations

### Service Boundaries
This order microservice is designed to operate independently within a larger microservices ecosystem:

- **Domain Ownership**: Owns all order-related data and business logic
- **API-First Design**: RESTful APIs enable integration with other services (inventory, payment, shipping)
- **Loose Coupling**: Communicates through well-defined contracts, not direct database access
- **Single Responsibility**: Focused solely on order management and lifecycle

### Data Ownership & Separation
**Monolith Decomposition Strategy:**
- Order data is cleanly separated from product catalog, customer, and inventory domains
- Uses customer references (names/IDs) rather than embedding customer data
- Product information is denormalized for order context (snapshot at time of order)
- Maintains referential integrity within order domain boundaries

**Data Consistency:**
- Eventual consistency with other services through event-driven patterns (future enhancement)
- Strong consistency within order domain using database transactions
- Immutable order history for audit and compliance requirements

### Cloud-Native Patterns

**Stateless Design:**
- No server-side session state
- Each request contains all necessary information
- Horizontal scaling capabilities without sticky sessions

**Externalized Configuration:**
- Environment-specific settings in `application.yml`
- Configurable database connections and logging levels
- Ready for configuration servers and environment variables

**Health & Monitoring:**
- Actuator endpoints for health checks and metrics
- Structured logging for observability
- Ready for integration with monitoring solutions (Prometheus, Grafana)

**Container Ready:**
- Dockerfile for consistent deployment
- Optimized for container orchestration (Kubernetes)
- Graceful shutdown and resource management

## Business Logic Implementation

### Order Validation Rules
The service implements meaningful business logic for order creation:

- **Quantity Constraints**: Orders must have between 1 and 1,000 items
- **Price Validation**: Minimum price of $0.01 per item
- **Order Value Limits**: Maximum total order value of $100,000
- **Data Integrity**: Comprehensive input validation using Bean Validation

### Order Status Transition Rules
Sophisticated business rules govern order status changes:

- **Workflow Enforcement**: Orders must follow logical progression (PENDING → CONFIRMED → PROCESSING → SHIPPED → DELIVERED)
- **Cancellation Rules**: Orders can be cancelled at any time except after delivery (returns only)
- **Immutable States**: Cancelled orders cannot be changed to other statuses
- **Business Constraints**: 
  - Cannot skip processing step when shipping
  - Cannot deliver unshipped orders
  - Must confirm pending orders before processing

### Error Handling
- **Global Exception Handler**: Consistent error responses across all endpoints with embedded ErrorResponse classes
- **Validation Errors**: Detailed field-level validation messages using ValidationErrorResponse
- **Business Rule Violations**: Clear error messages for status transition failures
- **HTTP Status Codes**: Appropriate status codes (400, 404, 500) based on error type

## Enterprise Features

### High Availability & Scaling
- **Stateless Design**: No server-side session state for horizontal scaling
- **Health Checks**: Comprehensive monitoring with Actuator endpoints
- **Container Ready**: Docker optimization for cloud deployment
- **Connection Pooling**: HikariCP for efficient database connections
- **Performance Monitoring**: Prometheus metrics integration

### Data Consistency & Reliability
- **Transaction Management**: ACID compliance within service boundaries
- **Business Rules Enforcement**: Status transition validation
- **Audit Trail**: Automatic timestamp tracking for all operations
- **Data Validation**: Comprehensive input validation at multiple layers
- **Error Recovery**: Graceful error handling and rollback mechanisms

### Cloud-Native Architecture
- **12-Factor App Compliance**: Configuration, logging, and process management
- **Environment Profiles**: Production, development, and test configurations
- **Externalized Configuration**: Environment variables and config servers
- **Health & Readiness Probes**: Kubernetes-ready health checks
- **Distributed Tracing Ready**: Prepared for observability integration

## Project Structure

```
src/
├── main/
│   ├── java/com/microservice/order/
│   │   ├── OrderMicroApplication.java          # Main Spring Boot application
│   │   ├── controller/
│   │   │   └── OrderController.java            # REST API endpoints
│   │   ├── service/
│   │   │   └── OrderService.java               # Business logic layer
│   │   ├── repository/
│   │   │   └── OrderRepository.java            # Data access layer
│   │   ├── entity/
│   │   │   ├── Order.java                      # JPA entity with lifecycle callbacks
│   │   │   └── OrderStatus.java                # Order status enumeration
│   │   ├── dto/
│   │   │   ├── CreateOrderRequest.java         # Request DTO with validation
│   │   │   └── OrderResponse.java              # Response DTO
│   │   └── exception/
│   │       ├── OrderNotFoundException.java     # Custom business exception
│   │       └── GlobalExceptionHandler.java     # Centralized error handling with embedded ErrorResponse classes
│   └── resources/
│       ├── application.yml                     # Main configuration
│       ├── application-test.yml                # Test environment config
│       ├── application-e2e.yml                 # E2E test environment config
│       ├── application-production.yml          # Production configuration
│       └── data.sql                            # Sample data for development
└── test/
    └── java/com/microservice/order/
        ├── OrderMicroApplicationTests.java     # Application context test
        ├── dto/
        │   └── CreateOrderRequestTest.java     # DTO unit tests (6 tests)
        ├── entity/
        │   └── OrderTest.java                  # Entity unit tests (9 tests)
        ├── repository/
        │   └── OrderRepositoryTest.java        # Repository integration tests (16 tests)
        ├── service/
        │   └── OrderServiceTest.java           # Service unit tests (19 tests)
        ├── controller/
        │   └── OrderControllerTest.java        # Controller unit tests (13 tests)
        └── e2e/
            └── OrderMicroserviceE2ETest.java   # End-to-end tests (11 tests)

# Generated content and reports
target/
├── site/
│   ├── jacoco/                                 # Code coverage reports
│   │   └── index.html                          # Coverage dashboard
│   └── surefire-report.html                   # Test execution report
└── surefire-reports/                          # Individual test results

# Configuration and documentation
├── .github/
│   └── copilot-instructions.md                # Development guidelines
├── docker-compose.yml                         # Multi-container setup
├── Dockerfile                                 # Container definition
├── TEST_REPORT.md                             # Comprehensive test documentation
└── README.md                                  # This file
```

## API Endpoints

### Orders

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/orders` | Create a new order |
| GET | `/api/v1/orders` | Get all orders (with optional filters) |
| GET | `/api/v1/orders/{id}` | Get order by ID |
| PUT | `/api/v1/orders/{id}/status` | Update order status |
| DELETE | `/api/v1/orders/{id}` | Delete an order |
| GET | `/api/v1/orders/stats/count?status={status}` | Get order count by status |

### Query Parameters for GET /api/v1/orders

- `customerName`: Filter by customer name
- `status`: Filter by order status

### Health Check

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/order-service/actuator/health` | Application health status |

## Getting Started

### Prerequisites

- **Java 17 or higher** - Required for Spring Boot 3.x
- **Maven 3.6 or higher** - For building and dependency management
- **Docker** (optional) - For containerization and deployment
- **VS Code** (recommended) - Optimized with tasks and configurations

### Quick Start

1. **Clone and navigate to the project directory**

2. **Build the project:**
   ```bash
   mvn clean compile
   ```

3. **Run tests (recommended):**
   ```bash
   mvn test
   ```

4. **Run the application:**
   ```bash
   mvn spring-boot:run
   ```

5. **Access the application:**
   - API Base URL: `http://localhost:8080/order-service/api/v1`
   - H2 Console: `http://localhost:8080/order-service/h2-console`
   - Health Check: `http://localhost:8080/order-service/actuator/health`

### Development with VS Code

The project includes pre-configured VS Code tasks for common operations:

```bash
# Build and run the application
Ctrl+Shift+P -> "Tasks: Run Task" -> "Build and Run Order Microservice"

# Run all tests with coverage
Ctrl+Shift+P -> "Tasks: Run Task" -> "Run All Tests with Coverage"

# Generate HTML test reports
Ctrl+Shift+P -> "Tasks: Run Task" -> "Generate Site with All Reports"

# Open test coverage report
Ctrl+Shift+P -> "Tasks: Run Task" -> "Open Coverage Report"
```

### Available Maven Tasks

```bash
# Development tasks
mvn spring-boot:run                    # Run the application
mvn clean compile                      # Build the project
mvn test                              # Run unit and integration tests

# Testing and quality tasks
mvn clean test jacoco:report          # Run tests with coverage
mvn clean verify                      # Run all tests including E2E
mvn surefire-report:report            # Generate HTML test reports
mvn site                              # Generate full project site with reports

# Docker tasks
mvn clean package                     # Build JAR file
docker build -t order-microservice .  # Build Docker image
docker-compose up --build             # Run with Docker Compose
```

### Test Execution

The project includes comprehensive testing at multiple levels:

```bash
# Quick unit tests (fast)
mvn test -Dtest="*Test"

# Integration tests (medium)
mvn test -Dtest="*RepositoryTest"

# End-to-end tests (slow)
mvn test -Dtest="*E2ETest"

# Run specific test class
mvn test -Dtest=OrderServiceTest

# Generate coverage report and open in browser
mvn clean test jacoco:report && open target/site/jacoco/index.html
```

### H2 Database Access

- **URL:** `jdbc:h2:mem:orderdb`
- **Username:** `sa`
- **Password:** `password`

## API Usage Examples

### Create an Order

```bash
curl -X POST http://localhost:8080/order-service/api/v1/orders \
  -H "Content-Type: application/json" \
  -d '{
    "customerName": "John Doe",
    "productName": "Laptop",
    "quantity": 1,
    "price": 999.99
  }'
```

### Get All Orders

```bash
curl http://localhost:8080/order-service/api/v1/orders
```

### Get Orders by Customer

```bash
curl "http://localhost:8080/order-service/api/v1/orders?customerName=John%20Doe"
```

### Update Order Status

```bash
curl -X PUT http://localhost:8080/order-service/api/v1/orders/1/status \
  -H "Content-Type: application/json" \
  -d '{"status": "CONFIRMED"}'
```

## Docker Deployment

### Build and Run with Docker

```bash
# Build the application
mvn clean package

# Build Docker image
docker build -t order-microservice .

# Run the container
docker run -p 8080:8080 order-microservice
```

### Using Docker Compose

```bash
docker-compose up --build
```

## Testing & Quality Assurance

### Test Suite Overview

The project includes **63+ comprehensive tests** across multiple layers:

- **Unit Tests (49 tests)**: Entity, Service, Controller, and DTO layer validation
- **Integration Tests (13 tests)**: Repository and database interaction testing
- **End-to-End Tests (11 tests)**: Complete workflow and API testing

### Test Categories

| Test Type | Count | Purpose | Execution Time |
|-----------|-------|---------|----------------|
| DTO Tests | 6 | Data transfer object validation | < 1s |
| Entity Tests | 9 | Business logic and JPA lifecycle | < 1s |
| Service Tests | 19 | Business rules and orchestration | < 1s |
| Controller Tests | 13 | REST API and HTTP handling | < 2s |
| Repository Tests | 16 | Database queries and persistence | < 5s |
| E2E Tests | 11 | Complete system workflows | < 30s |

### Coverage Goals and Metrics

- **Line Coverage**: 80%+ (enforced by JaCoCo)
- **Branch Coverage**: 75%+ (enforced by JaCoCo)
- **Business Rules**: 100% coverage of critical business logic
- **Error Scenarios**: Comprehensive negative testing

### Test Execution Commands

```bash
# Run all tests with coverage
mvn clean test jacoco:report

# Run tests by category
mvn test -Dtest="*Test"           # Unit tests only
mvn test -Dtest="*RepositoryTest" # Integration tests
mvn test -Dtest="*E2ETest"        # End-to-end tests

# Generate HTML reports
mvn clean test surefire-report:report site

# Open reports in browser (macOS)
open target/site/jacoco/index.html        # Coverage report
open target/site/surefire-report.html     # Test execution report
```

### Test Documentation

See `TEST_REPORT.md` for comprehensive documentation of all test cases, including:
- Detailed test descriptions and purposes
- Business rule validation coverage
- Test categorization and execution strategies
- Quality metrics and coverage analysis

## Development

### Running Tests

```bash
mvn test                              # Run all tests
mvn test -Dtest=OrderServiceTest      # Run specific test class
mvn clean verify                     # Include E2E tests
mvn test jacoco:report               # Generate coverage report
```

### Building for Production

```bash
mvn clean package -DskipTests        # Build JAR without tests
mvn clean package                    # Build with full test execution
mvn clean verify jacoco:report       # Full build with coverage
```

### Code Quality Checks

The project enforces quality through:
- **JaCoCo Coverage**: Minimum thresholds enforced in build
- **Bean Validation**: Input validation at API and service layers
- **Checkstyle** (future): Code style enforcement
- **SpotBugs** (future): Static analysis for bug detection

## Monitoring and Health Checks

The application includes comprehensive monitoring capabilities:

### Spring Boot Actuator Endpoints

| Endpoint | Purpose | Description |
|----------|---------|-------------|
| `/order-service/actuator/health` | Health Check | Application and dependency health status |
| `/order-service/actuator/info` | Application Info | Build and version information |
| `/order-service/actuator/metrics` | Metrics | Application performance metrics |
| `/order-service/actuator/loggers` | Log Management | Dynamic log level configuration |

### Test and Coverage Reports

| Report Type | Location | Description |
|-------------|----------|-------------|
| Test Results | `target/site/surefire-report.html` | HTML test execution report |
| Coverage Report | `target/site/jacoco/index.html` | Code coverage analysis |
| Full Site | `target/site/index.html` | Complete project documentation |

### Production Monitoring

Ready for integration with:
- **Prometheus**: Metrics collection and alerting
- **Grafana**: Visualization and dashboards  
- **ELK Stack**: Centralized logging and analysis
- **Jaeger/Zipkin**: Distributed tracing (future enhancement)

### Health Check Examples

```bash
# Basic health check
curl http://localhost:8080/order-service/actuator/health

# Detailed health with components
curl http://localhost:8080/order-service/actuator/health/details

# Application metrics
curl http://localhost:8080/order-service/actuator/metrics
```

## Order Status Flow

```
PENDING → CONFIRMED → PROCESSING → SHIPPED → DELIVERED
    ↓
CANCELLED (can be set from any status)
```

## Contributing

### Development Guidelines

1. **Follow coding standards** defined in `.github/copilot-instructions.md`
2. **Write comprehensive tests** for all new features and bug fixes
3. **Maintain test coverage** above 80% line coverage and 75% branch coverage
4. **Run full test suite** before submitting changes: `mvn clean verify jacoco:report`
5. **Use proper commit messages** following conventional commit format
6. **Update documentation** including README and TEST_REPORT when needed

### Development Workflow

```bash
# 1. Create feature branch
git checkout -b feature/your-feature-name

# 2. Implement changes with tests
# Write code and corresponding tests

# 3. Run quality checks
mvn clean test jacoco:report                    # Unit and integration tests
mvn clean verify                               # Include E2E tests
mvn clean test surefire-report:report site     # Generate reports

# 4. Verify coverage thresholds
open target/site/jacoco/index.html             # Check coverage report

# 5. Commit and push changes
git add .
git commit -m "feat: add new feature with comprehensive tests"
git push origin feature/your-feature-name
```

### Testing Requirements

- **Unit Tests**: Required for all service layer business logic
- **Integration Tests**: Required for new repository methods
- **Controller Tests**: Required for all new API endpoints
- **E2E Tests**: Required for new business workflows
- **Error Handling**: Test both success and failure scenarios

### Code Quality Standards

- **Spring Boot Best Practices**: Follow framework conventions
- **Clean Architecture**: Maintain proper layer separation
- **Exception Handling**: Use global exception handlers
- **Validation**: Implement comprehensive input validation
- **Documentation**: Include JavaDoc for public APIs

## License

This project is licensed under the MIT License.
