<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

# Order Microservice Project Instructions

This is a Spring Boot microservice project for order management. When working on this project:

## Code Style and Patterns
- Follow Spring Boot best practices and conventions
- Use proper dependency injection with constructor injection
- Implement proper validation using Bean Validation annotations
- Use DTOs for API requests/responses to maintain clean separation
- Follow RESTful API design principles

## Architecture Guidelines
- Maintain clean architecture with proper layer separation (Controller → Service → Repository)
- Use proper exception handling with global exception handlers
- Implement proper logging at appropriate levels
- Follow the existing package structure under `com.microservice.order`

## Database and JPA
- Use JPA entities with proper annotations
- Implement audit fields (createdAt, updatedAt) using JPA lifecycle callbacks
- Use proper query methods in repositories
- Follow naming conventions for database tables and columns

## Testing
- Write unit tests for service layer logic
- Use `@SpringBootTest` for integration tests
- Mock external dependencies appropriately
- Test both happy path and error scenarios

## API Documentation
- Use proper HTTP status codes
- Implement consistent error response formats
- Follow REST conventions for endpoint naming
- Use appropriate request/response DTOs

## Security Considerations
- Validate all input data
- Use proper exception handling to avoid information leakage
- Implement proper CORS configuration if needed
