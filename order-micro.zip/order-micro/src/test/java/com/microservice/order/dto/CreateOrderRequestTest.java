package com.microservice.order.dto;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

@DisplayName("CreateOrderRequest DTO Tests")
class CreateOrderRequestTest {

    @Nested
    @DisplayName("Constructor Tests")
    class ConstructorTests {

        @Test
        @DisplayName("Should create DTO with all parameters")
        void shouldCreateDtoWithAllParameters() {
            // Given
            String customerName = "John Doe";
            String productName = "Laptop";
            Integer quantity = 2;
            BigDecimal price = new BigDecimal("999.99");

            // When
            CreateOrderRequest request = new CreateOrderRequest(customerName, productName, quantity, price);

            // Then
            assertEquals(customerName, request.getCustomerName());
            assertEquals(productName, request.getProductName());
            assertEquals(quantity, request.getQuantity());
            assertEquals(price, request.getPrice());
        }

        @Test
        @DisplayName("Should create empty DTO with default constructor")
        void shouldCreateEmptyDtoWithDefaultConstructor() {
            // When
            CreateOrderRequest request = new CreateOrderRequest();

            // Then
            assertNull(request.getCustomerName());
            assertNull(request.getProductName());
            assertNull(request.getQuantity());
            assertNull(request.getPrice());
        }
    }

    @Nested
    @DisplayName("Setter/Getter Tests")
    class SetterGetterTests {

        @Test
        @DisplayName("Should set and get customer name")
        void shouldSetAndGetCustomerName() {
            // Given
            CreateOrderRequest request = new CreateOrderRequest();
            String customerName = "Jane Smith";

            // When
            request.setCustomerName(customerName);

            // Then
            assertEquals(customerName, request.getCustomerName());
        }

        @Test
        @DisplayName("Should set and get product name")
        void shouldSetAndGetProductName() {
            // Given
            CreateOrderRequest request = new CreateOrderRequest();
            String productName = "Monitor";

            // When
            request.setProductName(productName);

            // Then
            assertEquals(productName, request.getProductName());
        }

        @Test
        @DisplayName("Should set and get quantity")
        void shouldSetAndGetQuantity() {
            // Given
            CreateOrderRequest request = new CreateOrderRequest();
            Integer quantity = 5;

            // When
            request.setQuantity(quantity);

            // Then
            assertEquals(quantity, request.getQuantity());
        }

        @Test
        @DisplayName("Should set and get price")
        void shouldSetAndGetPrice() {
            // Given
            CreateOrderRequest request = new CreateOrderRequest();
            BigDecimal price = new BigDecimal("299.99");

            // When
            request.setPrice(price);

            // Then
            assertEquals(price, request.getPrice());
        }
    }
}
