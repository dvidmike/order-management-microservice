package com.microservice.order.repository;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ActiveProfiles;

import com.microservice.order.entity.Order;
import com.microservice.order.entity.OrderStatus;

@DataJpaTest
@ActiveProfiles("test")
@DisplayName("OrderRepository Integration Tests")
class OrderRepositoryTest {

    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private OrderRepository orderRepository;

    private Order order1;
    private Order order2;
    private Order order3;

    @BeforeEach
    void setUp() {
        order1 = new Order("John Doe", "Laptop", 1, new BigDecimal("999.99"));
        order1.setStatus(OrderStatus.PENDING);

        order2 = new Order("John Doe", "Mouse", 2, new BigDecimal("25.00"));
        order2.setStatus(OrderStatus.CONFIRMED);

        order3 = new Order("Jane Smith", "Keyboard", 1, new BigDecimal("75.00"));
        order3.setStatus(OrderStatus.PENDING);

        entityManager.persistAndFlush(order1);
        entityManager.persistAndFlush(order2);
        entityManager.persistAndFlush(order3);
    }

    @Nested
    @DisplayName("Basic CRUD Operations")
    class BasicCrudOperations {

        @Test
        @DisplayName("Should save and find order by ID")
        void shouldSaveAndFindOrderById() {
            // Given
            Order newOrder = new Order("Alice Brown", "Monitor", 1, new BigDecimal("299.99"));

            // When
            Order saved = orderRepository.save(newOrder);
            Optional<Order> found = orderRepository.findById(saved.getId());

            // Then
            assertTrue(found.isPresent());
            assertEquals("Alice Brown", found.get().getCustomerName());
            assertEquals("Monitor", found.get().getProductName());
            assertEquals(OrderStatus.PENDING, found.get().getStatus());
            assertNotNull(found.get().getCreatedAt());
            assertNotNull(found.get().getUpdatedAt());
        }

        @Test
        @DisplayName("Should return empty when order not found")
        void shouldReturnEmptyWhenOrderNotFound() {
            // When
            Optional<Order> found = orderRepository.findById(999L);

            // Then
            assertFalse(found.isPresent());
        }

        @Test
        @DisplayName("Should find all orders")
        void shouldFindAllOrders() {
            // When
            List<Order> orders = orderRepository.findAll();

            // Then
            assertEquals(3, orders.size());
        }

        @Test
        @DisplayName("Should delete order")
        void shouldDeleteOrder() {
            // Given
            Long orderId = order1.getId();

            // When
            orderRepository.deleteById(orderId);
            Optional<Order> found = orderRepository.findById(orderId);

            // Then
            assertFalse(found.isPresent());
        }
    }

    @Nested
    @DisplayName("Custom Query Methods")
    class CustomQueryMethods {

        @Test
        @DisplayName("Should find orders by customer name")
        void shouldFindOrdersByCustomerName() {
            // When
            List<Order> johnOrders = orderRepository.findByCustomerName("John Doe");
            List<Order> janeOrders = orderRepository.findByCustomerName("Jane Smith");

            // Then
            assertEquals(2, johnOrders.size());
            assertEquals(1, janeOrders.size());
            assertTrue(johnOrders.stream().allMatch(order -> "John Doe".equals(order.getCustomerName())));
            assertTrue(janeOrders.stream().allMatch(order -> "Jane Smith".equals(order.getCustomerName())));
        }

        @Test
        @DisplayName("Should find orders by status")
        void shouldFindOrdersByStatus() {
            // When
            List<Order> pendingOrders = orderRepository.findByStatus(OrderStatus.PENDING);
            List<Order> confirmedOrders = orderRepository.findByStatus(OrderStatus.CONFIRMED);

            // Then
            assertEquals(2, pendingOrders.size());
            assertEquals(1, confirmedOrders.size());
            assertTrue(pendingOrders.stream().allMatch(order -> OrderStatus.PENDING.equals(order.getStatus())));
            assertTrue(confirmedOrders.stream().allMatch(order -> OrderStatus.CONFIRMED.equals(order.getStatus())));
        }

        @Test
        @DisplayName("Should find orders by customer name and status")
        void shouldFindOrdersByCustomerNameAndStatus() {
            // When
            List<Order> johnPendingOrders = orderRepository.findByCustomerNameAndStatus("John Doe", OrderStatus.PENDING);
            List<Order> johnConfirmedOrders = orderRepository.findByCustomerNameAndStatus("John Doe", OrderStatus.CONFIRMED);

            // Then
            assertEquals(1, johnPendingOrders.size());
            assertEquals(1, johnConfirmedOrders.size());
            assertEquals("John Doe", johnPendingOrders.get(0).getCustomerName());
            assertEquals(OrderStatus.PENDING, johnPendingOrders.get(0).getStatus());
        }

        @Test
        @DisplayName("Should count orders by status")
        void shouldCountOrdersByStatus() {
            // When
            long pendingCount = orderRepository.countByStatus(OrderStatus.PENDING);
            long confirmedCount = orderRepository.countByStatus(OrderStatus.CONFIRMED);
            long shippedCount = orderRepository.countByStatus(OrderStatus.SHIPPED);

            // Then
            assertEquals(2, pendingCount);
            assertEquals(1, confirmedCount);
            assertEquals(0, shippedCount);
        }

        @Test
        @DisplayName("Should find orders between dates")
        void shouldFindOrdersBetweenDates() {
            // Given
            LocalDateTime startDate = LocalDateTime.now().minusHours(1);
            LocalDateTime endDate = LocalDateTime.now().plusHours(1);

            // When
            List<Order> orders = orderRepository.findOrdersBetweenDates(startDate, endDate);

            // Then
            assertEquals(3, orders.size());
        }

        @Test
        @DisplayName("Should return empty list when no orders in date range")
        void shouldReturnEmptyListWhenNoOrdersInDateRange() {
            // Given
            LocalDateTime startDate = LocalDateTime.now().minusDays(2);
            LocalDateTime endDate = LocalDateTime.now().minusDays(1);

            // When
            List<Order> orders = orderRepository.findOrdersBetweenDates(startDate, endDate);

            // Then
            assertTrue(orders.isEmpty());
        }
    }

    @Nested
    @DisplayName("Entity Lifecycle Tests")
    class EntityLifecycleTests {

        @Test
        @DisplayName("Should automatically set created and updated timestamps")
        void shouldAutomaticallySetTimestamps() {
            // Given
            Order order = new Order("Test Customer", "Test Product", 1, new BigDecimal("10.00"));

            // When
            Order saved = orderRepository.save(order);

            // Then
            assertNotNull(saved.getCreatedAt());
            assertNotNull(saved.getUpdatedAt());
            // Check that timestamps are set within a reasonable time frame (1 second)
            assertTrue(
                Math.abs(java.time.Duration.between(saved.getCreatedAt(), saved.getUpdatedAt()).toMillis()) < 1000,
                "Created and updated timestamps should be very close for new entities"
            );
        }

        @Test
        @DisplayName("Should update timestamp on entity modification")
        void shouldUpdateTimestampOnEntityModification() throws InterruptedException {
            // Given
            Order order = orderRepository.save(new Order("Test Customer", "Test Product", 1, new BigDecimal("10.00")));
            entityManager.flush(); // Ensure the entity is persisted
            LocalDateTime originalUpdatedAt = order.getUpdatedAt();

            // Wait a bit to ensure timestamp difference
            Thread.sleep(100); // Increase sleep time

            // When
            order.setStatus(OrderStatus.CONFIRMED);
            Order updated = orderRepository.saveAndFlush(order); // Use saveAndFlush to trigger lifecycle

            // Then
            assertNotNull(updated.getUpdatedAt());
            assertTrue(updated.getUpdatedAt().isAfter(originalUpdatedAt) || updated.getUpdatedAt().isEqual(originalUpdatedAt.plusNanos(1)),
                "Updated timestamp should be after original timestamp. Original: " + originalUpdatedAt + 
                ", Updated: " + updated.getUpdatedAt());
            assertEquals(order.getCreatedAt(), updated.getCreatedAt()); // createdAt should not change
        }

        @Test
        @DisplayName("Should calculate total amount correctly")
        void shouldCalculateTotalAmountCorrectly() {
            // Given
            Order order = new Order("Test Customer", "Test Product", 3, new BigDecimal("25.50"));

            // When
            Order saved = orderRepository.save(order);

            // Then
            assertEquals(new BigDecimal("76.50"), saved.getTotalAmount());
        }
    }

    @Nested
    @DisplayName("Edge Cases and Error Handling")
    class EdgeCasesAndErrorHandling {

        @Test
        @DisplayName("Should handle empty customer name search")
        void shouldHandleEmptyCustomerNameSearch() {
            // When
            List<Order> orders = orderRepository.findByCustomerName("");

            // Then
            assertTrue(orders.isEmpty());
        }

        @Test
        @DisplayName("Should handle null customer name search gracefully")
        void shouldHandleNullCustomerNameSearchGracefully() {
            // When
            List<Order> orders = orderRepository.findByCustomerName(null);

            // Then
            assertTrue(orders.isEmpty());
        }

        @Test
        @DisplayName("Should handle case-sensitive customer name search")
        void shouldHandleCaseSensitiveCustomerNameSearch() {
            // When
            List<Order> upperCaseOrders = orderRepository.findByCustomerName("JOHN DOE");
            List<Order> lowerCaseOrders = orderRepository.findByCustomerName("john doe");
            List<Order> correctCaseOrders = orderRepository.findByCustomerName("John Doe");

            // Then
            assertTrue(upperCaseOrders.isEmpty());
            assertTrue(lowerCaseOrders.isEmpty());
            assertEquals(2, correctCaseOrders.size());
        }
    }
}
