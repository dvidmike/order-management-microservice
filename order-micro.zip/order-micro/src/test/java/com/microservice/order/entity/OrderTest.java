package com.microservice.order.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

@DisplayName("Order Entity Unit Tests")
class OrderTest {

    @Nested
    @DisplayName("Order Creation Tests")
    class OrderCreationTests {

        @Test
        @DisplayName("Should create order with valid data")
        void shouldCreateOrderWithValidData() {
            // Given
            String customerName = "John Doe";
            String productName = "Laptop";
            Integer quantity = 2;
            BigDecimal price = new BigDecimal("999.99");

            // When
            Order order = new Order(customerName, productName, quantity, price);

            // Then
            assertEquals(customerName, order.getCustomerName());
            assertEquals(productName, order.getProductName());
            assertEquals(quantity, order.getQuantity());
            assertEquals(price, order.getPrice());
            assertEquals(OrderStatus.PENDING, order.getStatus());
            assertNull(order.getId());
            assertNull(order.getCreatedAt());
            assertNull(order.getUpdatedAt());
        }

        @Test
        @DisplayName("Should have default status as PENDING")
        void shouldHaveDefaultStatusAsPending() {
            // When
            Order order = new Order();

            // Then
            assertEquals(OrderStatus.PENDING, order.getStatus());
        }
    }

    @Nested
    @DisplayName("Total Amount Calculation Tests")
    class TotalAmountCalculationTests {

        @Test
        @DisplayName("Should calculate total amount correctly")
        void shouldCalculateTotalAmountCorrectly() {
            // Given
            Order order = new Order("Customer", "Product", 3, new BigDecimal("25.50"));

            // When
            BigDecimal totalAmount = order.getTotalAmount();

            // Then
            assertEquals(new BigDecimal("76.50"), totalAmount);
        }

        @Test
        @DisplayName("Should handle single item calculation")
        void shouldHandleSingleItemCalculation() {
            // Given
            Order order = new Order("Customer", "Product", 1, new BigDecimal("99.99"));

            // When
            BigDecimal totalAmount = order.getTotalAmount();

            // Then
            assertEquals(new BigDecimal("99.99"), totalAmount);
        }

        @Test
        @DisplayName("Should handle large quantities")
        void shouldHandleLargeQuantities() {
            // Given
            Order order = new Order("Customer", "Product", 100, new BigDecimal("1.00"));

            // When
            BigDecimal totalAmount = order.getTotalAmount();

            // Then
            assertEquals(new BigDecimal("100.00"), totalAmount);
        }
    }

    @Nested
    @DisplayName("Lifecycle Callback Tests")
    class LifecycleCallbackTests {

        @Test
        @DisplayName("Should set timestamps on create")
        void shouldSetTimestampsOnCreate() {
            // Given
            LocalDateTime beforeCreate = LocalDateTime.now();
            Order order = new Order("Customer", "Product", 1, new BigDecimal("10.00"));

            // When
            order.onCreate();
            LocalDateTime afterCreate = LocalDateTime.now();

            // Then
            assertNotNull(order.getCreatedAt());
            assertNotNull(order.getUpdatedAt());
            assertTrue(order.getCreatedAt().isAfter(beforeCreate.minusSeconds(1)) || order.getCreatedAt().isEqual(beforeCreate));
            assertTrue(order.getCreatedAt().isBefore(afterCreate.plusSeconds(1)) || order.getCreatedAt().isEqual(afterCreate));
            assertEquals(order.getCreatedAt(), order.getUpdatedAt()); // They should be equal on create
            }

        @Test
        @DisplayName("Should update timestamp on update")
        void shouldUpdateTimestampOnUpdate() {
            // Given
            Order order = new Order("Customer", "Product", 1, new BigDecimal("10.00"));
            order.onCreate();
            LocalDateTime originalCreatedAt = order.getCreatedAt();
            LocalDateTime originalUpdatedAt = order.getUpdatedAt();

            // When
            LocalDateTime beforeUpdate = LocalDateTime.now();
            order.onUpdate();
            LocalDateTime afterUpdate = LocalDateTime.now();

            // Then
            assertEquals(originalCreatedAt, order.getCreatedAt()); // Should not change
            assertNotNull(order.getUpdatedAt());
            assertTrue(order.getUpdatedAt().isAfter(originalUpdatedAt));
            assertTrue(order.getUpdatedAt().isAfter(beforeUpdate) || order.getUpdatedAt().isEqual(beforeUpdate));
            assertTrue(order.getUpdatedAt().isBefore(afterUpdate) || order.getUpdatedAt().isEqual(afterUpdate));
        }
    }

    @Nested
    @DisplayName("Setter/Getter Tests")
    class SetterGetterTests {

        @Test
        @DisplayName("Should set and get all properties correctly")
        void shouldSetAndGetAllPropertiesCorrectly() {
            // Given
            Order order = new Order();
            Long id = 1L;
            String customerName = "Jane Smith";
            String productName = "Monitor";
            Integer quantity = 2;
            BigDecimal price = new BigDecimal("199.99");
            OrderStatus status = OrderStatus.CONFIRMED;
            LocalDateTime now = LocalDateTime.now();

            // When
            order.setId(id);
            order.setCustomerName(customerName);
            order.setProductName(productName);
            order.setQuantity(quantity);
            order.setPrice(price);
            order.setStatus(status);
            order.setCreatedAt(now);
            order.setUpdatedAt(now);

            // Then
            assertEquals(id, order.getId());
            assertEquals(customerName, order.getCustomerName());
            assertEquals(productName, order.getProductName());
            assertEquals(quantity, order.getQuantity());
            assertEquals(price, order.getPrice());
            assertEquals(status, order.getStatus());
            assertEquals(now, order.getCreatedAt());
            assertEquals(now, order.getUpdatedAt());
        }
    }
}
