package com.microservice.order.controller;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.mockito.ArgumentMatchers.any;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.microservice.order.dto.CreateOrderRequest;
import com.microservice.order.dto.OrderResponse;
import com.microservice.order.entity.OrderStatus;
import com.microservice.order.exception.GlobalExceptionHandler;
import com.microservice.order.exception.OrderNotFoundException;
import com.microservice.order.service.OrderService;

@ExtendWith(MockitoExtension.class)
@DisplayName("OrderController Unit Tests")
class OrderControllerTest {

    @Mock
    private OrderService orderService;

    @InjectMocks
    private OrderController orderController;

    private MockMvc mockMvc;

    private ObjectMapper objectMapper;

    private OrderResponse sampleOrderResponse;
    private CreateOrderRequest sampleCreateRequest;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(orderController)
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();
        objectMapper = new ObjectMapper();
        
        sampleOrderResponse = new OrderResponse(
            1L, "John Doe", "Laptop", 2, new BigDecimal("999.99"), 
            new BigDecimal("1999.98"), OrderStatus.PENDING, 
            LocalDateTime.now(), LocalDateTime.now()
        );

        sampleCreateRequest = new CreateOrderRequest("John Doe", "Laptop", 2, new BigDecimal("999.99"));
    }

    @Nested
    @DisplayName("Create Order Endpoint Tests")
    class CreateOrderEndpointTests {

        @Test
        @DisplayName("Should create order successfully with valid data")
        void shouldCreateOrderSuccessfully() throws Exception {
            // Given
            when(orderService.createOrder(any(CreateOrderRequest.class))).thenReturn(sampleOrderResponse);

            // When & Then
            mockMvc.perform(post("/api/v1/orders")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(sampleCreateRequest)))
                    .andExpect(status().isCreated())
                    .andExpect(jsonPath("$.id").value(1))
                    .andExpect(jsonPath("$.customerName").value("John Doe"))
                    .andExpect(jsonPath("$.productName").value("Laptop"))
                    .andExpect(jsonPath("$.quantity").value(2))
                    .andExpect(jsonPath("$.price").value(999.99))
                    .andExpect(jsonPath("$.totalAmount").value(1999.98))
                    .andExpect(jsonPath("$.status").value("PENDING"));

            verify(orderService).createOrder(any(CreateOrderRequest.class));
        }

        @Test
        @DisplayName("Should return bad request for invalid data")
        void shouldReturnBadRequestForInvalidData() throws Exception {
            // Given
            CreateOrderRequest invalidRequest = new CreateOrderRequest("", "", -1, new BigDecimal("-10"));

            // When & Then
            mockMvc.perform(post("/api/v1/orders")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(invalidRequest)))
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.status").value(400))
                    .andExpect(jsonPath("$.message").value("Validation failed"))
                    .andExpect(jsonPath("$.errors").exists());

            verify(orderService, never()).createOrder(any(CreateOrderRequest.class));
        }

        @Test
        @DisplayName("Should handle business rule violations")
        void shouldHandleBusinessRuleViolations() throws Exception {
            // Given
            when(orderService.createOrder(any(CreateOrderRequest.class)))
                .thenThrow(new IllegalArgumentException("Order quantity must be at least 1"));

            // When & Then
            mockMvc.perform(post("/api/v1/orders")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(sampleCreateRequest)))
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.status").value(400))
                    .andExpect(jsonPath("$.message").value("Order quantity must be at least 1"));

            verify(orderService).createOrder(any(CreateOrderRequest.class));
        }
    }

    @Nested
    @DisplayName("Get Order Endpoint Tests")
    class GetOrderEndpointTests {

        @Test
        @DisplayName("Should return order by ID")
        void shouldReturnOrderById() throws Exception {
            // Given
            when(orderService.getOrderById(1L)).thenReturn(sampleOrderResponse);

            // When & Then
            mockMvc.perform(get("/api/v1/orders/1"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.id").value(1))
                    .andExpect(jsonPath("$.customerName").value("John Doe"));

            verify(orderService).getOrderById(1L);
        }

        @Test
        @DisplayName("Should return 404 when order not found")
        void shouldReturn404WhenOrderNotFound() throws Exception {
            // Given
            when(orderService.getOrderById(999L)).thenThrow(new OrderNotFoundException("Order not found with id: 999"));

            // When & Then
            mockMvc.perform(get("/api/v1/orders/999"))
                    .andExpect(status().isNotFound())
                    .andExpect(jsonPath("$.status").value(404))
                    .andExpect(jsonPath("$.message").value("Order not found with id: 999"));

            verify(orderService).getOrderById(999L);
        }

        @Test
        @DisplayName("Should return all orders without filters")
        void shouldReturnAllOrdersWithoutFilters() throws Exception {
            // Given
            List<OrderResponse> orders = Arrays.asList(sampleOrderResponse);
            when(orderService.getAllOrders()).thenReturn(orders);

            // When & Then
            mockMvc.perform(get("/api/v1/orders"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$").isArray())
                    .andExpect(jsonPath("$[0].id").value(1))
                    .andExpect(jsonPath("$[0].customerName").value("John Doe"));

            verify(orderService).getAllOrders();
        }

        @Test
        @DisplayName("Should return orders filtered by customer name")
        void shouldReturnOrdersFilteredByCustomerName() throws Exception {
            // Given
            List<OrderResponse> orders = Arrays.asList(sampleOrderResponse);
            when(orderService.getOrdersByCustomer("John Doe")).thenReturn(orders);

            // When & Then
            mockMvc.perform(get("/api/v1/orders").param("customerName", "John Doe"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$").isArray())
                    .andExpect(jsonPath("$[0].customerName").value("John Doe"));

            verify(orderService).getOrdersByCustomer("John Doe");
        }

        @Test
        @DisplayName("Should return orders filtered by status")
        void shouldReturnOrdersFilteredByStatus() throws Exception {
            // Given
            List<OrderResponse> orders = Arrays.asList(sampleOrderResponse);
            when(orderService.getOrdersByStatus(OrderStatus.PENDING)).thenReturn(orders);

            // When & Then
            mockMvc.perform(get("/api/v1/orders").param("status", "PENDING"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$").isArray())
                    .andExpect(jsonPath("$[0].status").value("PENDING"));

            verify(orderService).getOrdersByStatus(OrderStatus.PENDING);
        }
    }

    @Nested
    @DisplayName("Update Order Status Endpoint Tests")
    class UpdateOrderStatusEndpointTests {

        @Test
        @DisplayName("Should update order status successfully")
        void shouldUpdateOrderStatusSuccessfully() throws Exception {
            // Given
            OrderResponse updatedResponse = new OrderResponse(
                1L, "John Doe", "Laptop", 2, new BigDecimal("999.99"), 
                new BigDecimal("1999.98"), OrderStatus.CONFIRMED, 
                LocalDateTime.now(), LocalDateTime.now()
            );
            when(orderService.updateOrderStatus(1L, OrderStatus.CONFIRMED)).thenReturn(updatedResponse);

            // When & Then
            mockMvc.perform(put("/api/v1/orders/1/status")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content("{\"status\": \"CONFIRMED\"}"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.id").value(1))
                    .andExpect(jsonPath("$.status").value("CONFIRMED"));

            verify(orderService).updateOrderStatus(1L, OrderStatus.CONFIRMED);
        }

        @Test
        @DisplayName("Should handle invalid status transition")
        void shouldHandleInvalidStatusTransition() throws Exception {
            // Given
            when(orderService.updateOrderStatus(1L, OrderStatus.SHIPPED))
                .thenThrow(new IllegalStateException("Orders must be processed before shipping"));

            // When & Then
            mockMvc.perform(put("/api/v1/orders/1/status")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content("{\"status\": \"SHIPPED\"}"))
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.status").value(400))
                    .andExpect(jsonPath("$.message").value("Orders must be processed before shipping"));

            verify(orderService).updateOrderStatus(1L, OrderStatus.SHIPPED);
        }
    }

    @Nested
    @DisplayName("Delete Order Endpoint Tests")
    class DeleteOrderEndpointTests {

        @Test
        @DisplayName("Should delete order successfully")
        void shouldDeleteOrderSuccessfully() throws Exception {
            // Given
            doNothing().when(orderService).deleteOrder(1L);

            // When & Then
            mockMvc.perform(delete("/api/v1/orders/1"))
                    .andExpect(status().isNoContent());

            verify(orderService).deleteOrder(1L);
        }

        @Test
        @DisplayName("Should return 404 when deleting non-existent order")
        void shouldReturn404WhenDeletingNonExistentOrder() throws Exception {
            // Given
            doThrow(new OrderNotFoundException("Order not found with id: 999"))
                .when(orderService).deleteOrder(999L);

            // When & Then
            mockMvc.perform(delete("/api/v1/orders/999"))
                    .andExpect(status().isNotFound())
                    .andExpect(jsonPath("$.status").value(404))
                    .andExpect(jsonPath("$.message").value("Order not found with id: 999"));

            verify(orderService).deleteOrder(999L);
        }
    }

    @Nested
    @DisplayName("Statistics Endpoint Tests")
    class StatisticsEndpointTests {

        @Test
        @DisplayName("Should return order statistics")
        void shouldReturnOrderStatistics() throws Exception {
            // Given
            when(orderService.getOrderCountByStatus(OrderStatus.PENDING)).thenReturn(5L);

            // When & Then
            mockMvc.perform(get("/api/v1/orders/stats/count").param("status", "PENDING"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.count").value(5))
                    .andExpect(jsonPath("$.status").value("PENDING"))
                    .andExpect(jsonPath("$.statusCode").value(0));

            verify(orderService).getOrderCountByStatus(OrderStatus.PENDING);
        }
    }
}
