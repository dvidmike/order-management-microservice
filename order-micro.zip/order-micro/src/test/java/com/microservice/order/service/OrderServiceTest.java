package com.microservice.order.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.mockito.ArgumentMatchers.any;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.mockito.junit.jupiter.MockitoExtension;

import com.microservice.order.dto.CreateOrderRequest;
import com.microservice.order.dto.OrderResponse;
import com.microservice.order.entity.Order;
import com.microservice.order.entity.OrderStatus;
import com.microservice.order.exception.OrderNotFoundException;
import com.microservice.order.repository.OrderRepository;

@ExtendWith(MockitoExtension.class)
@DisplayName("OrderService Unit Tests")
class OrderServiceTest {

    @Mock
    private OrderRepository orderRepository;

    @InjectMocks
    private OrderService orderService;

    private Order sampleOrder;
    private CreateOrderRequest sampleRequest;

    @BeforeEach
    void setUp() {
        sampleOrder = new Order("John Doe", "Laptop", 2, new BigDecimal("999.99"));
        sampleOrder.setId(1L);
        sampleOrder.setCreatedAt(LocalDateTime.now());
        sampleOrder.setUpdatedAt(LocalDateTime.now());

        sampleRequest = new CreateOrderRequest("John Doe", "Laptop", 2, new BigDecimal("999.99"));
    }

    @Nested
    @DisplayName("Create Order Tests")
    class CreateOrderTests {

        @Test
        @DisplayName("Should create order successfully with valid data")
        void shouldCreateOrderSuccessfully() {
            // Given
            when(orderRepository.save(any(Order.class))).thenReturn(sampleOrder);

            // When
            OrderResponse result = orderService.createOrder(sampleRequest);

            // Then
            assertNotNull(result);
            assertEquals("John Doe", result.getCustomerName());
            assertEquals("Laptop", result.getProductName());
            assertEquals(2, result.getQuantity());
            assertEquals(new BigDecimal("999.99"), result.getPrice());
            assertEquals(new BigDecimal("1999.98"), result.getTotalAmount());
            assertEquals(OrderStatus.PENDING, result.getStatus());

            verify(orderRepository).save(any(Order.class));
        }

        @Test
        @DisplayName("Should throw exception when quantity is zero")
        void shouldThrowExceptionWhenQuantityIsZero() {
            // Given
            CreateOrderRequest invalidRequest = new CreateOrderRequest("John Doe", "Laptop", 0, new BigDecimal("999.99"));

            // When & Then
            IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> orderService.createOrder(invalidRequest)
            );
            assertEquals("Order quantity must be at least 1", exception.getMessage());
            verify(orderRepository, never()).save(any(Order.class));
        }

        @Test
        @DisplayName("Should throw exception when quantity exceeds limit")
        void shouldThrowExceptionWhenQuantityExceedsLimit() {
            // Given
            CreateOrderRequest invalidRequest = new CreateOrderRequest("John Doe", "Laptop", 1500, new BigDecimal("999.99"));

            // When & Then
            IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> orderService.createOrder(invalidRequest)
            );
            assertEquals("Order quantity cannot exceed 1000 items per order", exception.getMessage());
            verify(orderRepository, never()).save(any(Order.class));
        }

        @Test
        @DisplayName("Should throw exception when price is too low")
        void shouldThrowExceptionWhenPriceIsTooLow() {
            // Given
            CreateOrderRequest invalidRequest = new CreateOrderRequest("John Doe", "Laptop", 1, new BigDecimal("0.005"));

            // When & Then
            IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> orderService.createOrder(invalidRequest)
            );
            assertEquals("Order price must be at least $0.01", exception.getMessage());
            verify(orderRepository, never()).save(any(Order.class));
        }

        @Test
        @DisplayName("Should throw exception when total value exceeds limit")
        void shouldThrowExceptionWhenTotalValueExceedsLimit() {
            // Given
            CreateOrderRequest invalidRequest = new CreateOrderRequest("John Doe", "Laptop", 200, new BigDecimal("1000.00"));

            // When & Then
            IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> orderService.createOrder(invalidRequest)
            );
            assertEquals("Total order value cannot exceed $100,000 per order", exception.getMessage());
            verify(orderRepository, never()).save(any(Order.class));
        }
    }

    @Nested
    @DisplayName("Get Order Tests")
    class GetOrderTests {

        @Test
        @DisplayName("Should return order when found by ID")
        void shouldReturnOrderWhenFoundById() {
            // Given
            when(orderRepository.findById(1L)).thenReturn(Optional.of(sampleOrder));

            // When
            OrderResponse result = orderService.getOrderById(1L);

            // Then
            assertNotNull(result);
            assertEquals(1L, result.getId());
            assertEquals("John Doe", result.getCustomerName());
            verify(orderRepository).findById(1L);
        }

        @Test
        @DisplayName("Should throw exception when order not found")
        void shouldThrowExceptionWhenOrderNotFound() {
            // Given
            when(orderRepository.findById(999L)).thenReturn(Optional.empty());

            // When & Then
            OrderNotFoundException exception = assertThrows(
                OrderNotFoundException.class,
                () -> orderService.getOrderById(999L)
            );
            assertEquals("Order not found with id: 999", exception.getMessage());
            verify(orderRepository).findById(999L);
        }

        @Test
        @DisplayName("Should return all orders")
        void shouldReturnAllOrders() {
            // Given
            Order order2 = new Order("Jane Smith", "Mouse", 1, new BigDecimal("25.00"));
            order2.setId(2L);
            List<Order> orders = Arrays.asList(sampleOrder, order2);
            when(orderRepository.findAll()).thenReturn(orders);

            // When
            List<OrderResponse> result = orderService.getAllOrders();

            // Then
            assertNotNull(result);
            assertEquals(2, result.size());
            assertEquals("John Doe", result.get(0).getCustomerName());
            assertEquals("Jane Smith", result.get(1).getCustomerName());
            verify(orderRepository).findAll();
        }

        @Test
        @DisplayName("Should return orders by customer name")
        void shouldReturnOrdersByCustomerName() {
            // Given
            List<Order> orders = Arrays.asList(sampleOrder);
            when(orderRepository.findByCustomerName("John Doe")).thenReturn(orders);

            // When
            List<OrderResponse> result = orderService.getOrdersByCustomer("John Doe");

            // Then
            assertNotNull(result);
            assertEquals(1, result.size());
            assertEquals("John Doe", result.get(0).getCustomerName());
            verify(orderRepository).findByCustomerName("John Doe");
        }

        @Test
        @DisplayName("Should return orders by status")
        void shouldReturnOrdersByStatus() {
            // Given
            List<Order> orders = Arrays.asList(sampleOrder);
            when(orderRepository.findByStatus(OrderStatus.PENDING)).thenReturn(orders);

            // When
            List<OrderResponse> result = orderService.getOrdersByStatus(OrderStatus.PENDING);

            // Then
            assertNotNull(result);
            assertEquals(1, result.size());
            assertEquals(OrderStatus.PENDING, result.get(0).getStatus());
            verify(orderRepository).findByStatus(OrderStatus.PENDING);
        }
    }

    @Nested
    @DisplayName("Update Order Status Tests")
    class UpdateOrderStatusTests {

        @Test
        @DisplayName("Should update status from PENDING to CONFIRMED")
        void shouldUpdateStatusFromPendingToConfirmed() {
            // Given
            when(orderRepository.findById(1L)).thenReturn(Optional.of(sampleOrder));
            when(orderRepository.save(any(Order.class))).thenReturn(sampleOrder);

            // When
            OrderResponse result = orderService.updateOrderStatus(1L, OrderStatus.CONFIRMED);

            // Then
            assertNotNull(result);
            verify(orderRepository).findById(1L);
            verify(orderRepository).save(any(Order.class));
        }

        @Test
        @DisplayName("Should throw exception when trying to change cancelled order")
        void shouldThrowExceptionWhenTryingToChangeCancelledOrder() {
            // Given
            sampleOrder.setStatus(OrderStatus.CANCELLED);
            when(orderRepository.findById(1L)).thenReturn(Optional.of(sampleOrder));

            // When & Then
            IllegalStateException exception = assertThrows(
                IllegalStateException.class,
                () -> orderService.updateOrderStatus(1L, OrderStatus.CONFIRMED)
            );
            assertEquals("Cannot change status of a cancelled order", exception.getMessage());
            verify(orderRepository).findById(1L);
            verify(orderRepository, never()).save(any(Order.class));
        }

        @Test
        @DisplayName("Should throw exception when skipping processing step")
        void shouldThrowExceptionWhenSkippingProcessingStep() {
            // Given
            sampleOrder.setStatus(OrderStatus.CONFIRMED);
            when(orderRepository.findById(1L)).thenReturn(Optional.of(sampleOrder));

            // When & Then
            IllegalStateException exception = assertThrows(
                IllegalStateException.class,
                () -> orderService.updateOrderStatus(1L, OrderStatus.SHIPPED)
            );
            assertEquals("Orders must be processed before shipping", exception.getMessage());
            verify(orderRepository).findById(1L);
            verify(orderRepository, never()).save(any(Order.class));
        }

        @Test
        @DisplayName("Should throw exception when trying to process pending order")
        void shouldThrowExceptionWhenTryingToProcessPendingOrder() {
            // Given
            when(orderRepository.findById(1L)).thenReturn(Optional.of(sampleOrder));

            // When & Then
            IllegalStateException exception = assertThrows(
                IllegalStateException.class,
                () -> orderService.updateOrderStatus(1L, OrderStatus.PROCESSING)
            );
            assertEquals("Orders must be confirmed before processing, shipping, or delivery", exception.getMessage());
            verify(orderRepository).findById(1L);
            verify(orderRepository, never()).save(any(Order.class));
        }

        @Test
        @DisplayName("Should throw exception when trying to deliver unshipped order")
        void shouldThrowExceptionWhenTryingToDeliverUnshippedOrder() {
            // Given
            sampleOrder.setStatus(OrderStatus.PROCESSING);
            when(orderRepository.findById(1L)).thenReturn(Optional.of(sampleOrder));

            // When & Then
            IllegalStateException exception = assertThrows(
                IllegalStateException.class,
                () -> orderService.updateOrderStatus(1L, OrderStatus.DELIVERED)
            );
            assertEquals("Orders must be shipped before delivery", exception.getMessage());
            verify(orderRepository).findById(1L);
            verify(orderRepository, never()).save(any(Order.class));
        }

        @Test
        @DisplayName("Should allow cancellation from delivered status")
        void shouldAllowCancellationFromDeliveredStatus() {
            // Given
            sampleOrder.setStatus(OrderStatus.DELIVERED);
            when(orderRepository.findById(1L)).thenReturn(Optional.of(sampleOrder));
            when(orderRepository.save(any(Order.class))).thenReturn(sampleOrder);

            // When
            OrderResponse result = orderService.updateOrderStatus(1L, OrderStatus.CANCELLED);

            // Then
            assertNotNull(result);
            verify(orderRepository).findById(1L);
            verify(orderRepository).save(any(Order.class));
        }
    }

    @Nested
    @DisplayName("Delete Order Tests")
    class DeleteOrderTests {

        @Test
        @DisplayName("Should delete existing order")
        void shouldDeleteExistingOrder() {
            // Given
            when(orderRepository.existsById(1L)).thenReturn(true);

            // When
            assertDoesNotThrow(() -> orderService.deleteOrder(1L));

            // Then
            verify(orderRepository).existsById(1L);
            verify(orderRepository).deleteById(1L);
        }

        @Test
        @DisplayName("Should throw exception when deleting non-existent order")
        void shouldThrowExceptionWhenDeletingNonExistentOrder() {
            // Given
            when(orderRepository.existsById(999L)).thenReturn(false);

            // When & Then
            OrderNotFoundException exception = assertThrows(
                OrderNotFoundException.class,
                () -> orderService.deleteOrder(999L)
            );
            assertEquals("Order not found with id: 999", exception.getMessage());
            verify(orderRepository).existsById(999L);
            verify(orderRepository, never()).deleteById(999L);
        }
    }

    @Nested
    @DisplayName("Statistics Tests")
    class StatisticsTests {

        @Test
        @DisplayName("Should return correct count by status")
        void shouldReturnCorrectCountByStatus() {
            // Given
            when(orderRepository.countByStatus(OrderStatus.PENDING)).thenReturn(5L);

            // When
            long count = orderService.getOrderCountByStatus(OrderStatus.PENDING);

            // Then
            assertEquals(5L, count);
            verify(orderRepository).countByStatus(OrderStatus.PENDING);
        }
    }
}
