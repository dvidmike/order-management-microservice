package com.microservice.order.e2e;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;

import com.microservice.order.dto.CreateOrderRequest;
import com.microservice.order.dto.OrderResponse;
import com.microservice.order.entity.OrderStatus;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("e2e")
@DisplayName("Order Microservice E2E Tests")
class OrderMicroserviceE2ETest {

    @LocalServerPort
    private int port;

    @Autowired
    private TestRestTemplate restTemplate;

    private String baseUrl;

    @BeforeEach
    void setUp() {
        baseUrl = "http://localhost:" + port + "/order-service/api/v1/orders";
    }

    @Nested
    @DisplayName("Order Lifecycle E2E Tests")
    class OrderLifecycleE2ETests {

        @Test
        @DisplayName("Should complete full order lifecycle from creation to delivery")
        void shouldCompleteFullOrderLifecycle() {
            // Step 1: Create an order
            CreateOrderRequest createRequest = new CreateOrderRequest("John Doe", "Laptop", 1, new BigDecimal("999.99"));
            
            ResponseEntity<OrderResponse> createResponse = restTemplate.postForEntity(
                baseUrl, createRequest, OrderResponse.class
            );
            
            assertEquals(HttpStatus.CREATED, createResponse.getStatusCode());
            assertNotNull(createResponse.getBody());
            OrderResponse createdOrder = createResponse.getBody();
            assertEquals(OrderStatus.PENDING, createdOrder.getStatus());
            Long orderId = createdOrder.getId();

            // Step 2: Confirm the order
            String statusUpdateUrl = baseUrl + "/" + orderId + "/status";
            HttpEntity<String> confirmRequest = new HttpEntity<>("{\"status\": \"CONFIRMED\"}");
            
            ResponseEntity<OrderResponse> confirmResponse = restTemplate.exchange(
                statusUpdateUrl, HttpMethod.PUT, confirmRequest, OrderResponse.class
            );
            
            assertEquals(HttpStatus.OK, confirmResponse.getStatusCode());
            assertEquals(OrderStatus.CONFIRMED, confirmResponse.getBody().getStatus());

            // Step 3: Process the order
            HttpEntity<String> processRequest = new HttpEntity<>("{\"status\": \"PROCESSING\"}");
            
            ResponseEntity<OrderResponse> processResponse = restTemplate.exchange(
                statusUpdateUrl, HttpMethod.PUT, processRequest, OrderResponse.class
            );
            
            assertEquals(HttpStatus.OK, processResponse.getStatusCode());
            assertEquals(OrderStatus.PROCESSING, processResponse.getBody().getStatus());

            // Step 4: Ship the order
            HttpEntity<String> shipRequest = new HttpEntity<>("{\"status\": \"SHIPPED\"}");
            
            ResponseEntity<OrderResponse> shipResponse = restTemplate.exchange(
                statusUpdateUrl, HttpMethod.PUT, shipRequest, OrderResponse.class
            );
            
            assertEquals(HttpStatus.OK, shipResponse.getStatusCode());
            assertEquals(OrderStatus.SHIPPED, shipResponse.getBody().getStatus());

            // Step 5: Deliver the order
            HttpEntity<String> deliverRequest = new HttpEntity<>("{\"status\": \"DELIVERED\"}");
            
            ResponseEntity<OrderResponse> deliverResponse = restTemplate.exchange(
                statusUpdateUrl, HttpMethod.PUT, deliverRequest, OrderResponse.class
            );
            
            assertEquals(HttpStatus.OK, deliverResponse.getStatusCode());
            assertEquals(OrderStatus.DELIVERED, deliverResponse.getBody().getStatus());

            // Step 6: Verify order can be retrieved
            ResponseEntity<OrderResponse> getResponse = restTemplate.getForEntity(
                baseUrl + "/" + orderId, OrderResponse.class
            );
            
            assertEquals(HttpStatus.OK, getResponse.getStatusCode());
            assertEquals(OrderStatus.DELIVERED, getResponse.getBody().getStatus());
        }

        @Test
        @DisplayName("Should handle order cancellation at different stages")
        void shouldHandleOrderCancellationAtDifferentStages() {
            // Create and cancel from PENDING
            CreateOrderRequest createRequest = new CreateOrderRequest("Jane Smith", "Mouse", 2, new BigDecimal("25.00"));
            
            ResponseEntity<OrderResponse> createResponse = restTemplate.postForEntity(
                baseUrl, createRequest, OrderResponse.class
            );
            
            Long orderId = createResponse.getBody().getId();
            String statusUpdateUrl = baseUrl + "/" + orderId + "/status";
            
            // Cancel from PENDING
            HttpEntity<String> cancelRequest = new HttpEntity<>("{\"status\": \"CANCELLED\"}");
            ResponseEntity<OrderResponse> cancelResponse = restTemplate.exchange(
                statusUpdateUrl, HttpMethod.PUT, cancelRequest, OrderResponse.class
            );
            
            assertEquals(HttpStatus.OK, cancelResponse.getStatusCode());
            assertEquals(OrderStatus.CANCELLED, cancelResponse.getBody().getStatus());

            // Try to change status of cancelled order (should fail)
            HttpEntity<String> confirmRequest = new HttpEntity<>("{\"status\": \"CONFIRMED\"}");
            ResponseEntity<String> failedResponse = restTemplate.exchange(
                statusUpdateUrl, HttpMethod.PUT, confirmRequest, String.class
            );
            
            assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, failedResponse.getStatusCode());
        }
    }

    @Nested
    @DisplayName("Business Rules Validation E2E Tests")
    class BusinessRulesValidationE2ETests {

        @Test
        @DisplayName("Should enforce quantity limits")
        void shouldEnforceQuantityLimits() {
            // Test minimum quantity violation
            CreateOrderRequest invalidRequest = new CreateOrderRequest("Test Customer", "Product", 0, new BigDecimal("10.00"));
            
            ResponseEntity<String> response = restTemplate.postForEntity(
                baseUrl, invalidRequest, String.class
            );
            
            assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
            assertTrue(response.getBody().contains("Quantity must be positive"));

            // Test maximum quantity violation
            CreateOrderRequest maxQuantityRequest = new CreateOrderRequest("Test Customer", "Product", 1500, new BigDecimal("10.00"));
            
            ResponseEntity<String> maxResponse = restTemplate.postForEntity(
                baseUrl, maxQuantityRequest, String.class
            );
            
            assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, maxResponse.getStatusCode());
        }

        @Test
        @DisplayName("Should enforce order value limits")
        void shouldEnforceOrderValueLimits() {
            // Test minimum price violation
            CreateOrderRequest lowPriceRequest = new CreateOrderRequest("Test Customer", "Product", 1, new BigDecimal("0.005"));
            
            ResponseEntity<String> response = restTemplate.postForEntity(
                baseUrl, lowPriceRequest, String.class
            );
            
            assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());

            // Test maximum order value violation
            CreateOrderRequest highValueRequest = new CreateOrderRequest("Test Customer", "Product", 200, new BigDecimal("1000.00"));
            
            ResponseEntity<String> highValueResponse = restTemplate.postForEntity(
                baseUrl, highValueRequest, String.class
            );
            
            assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, highValueResponse.getStatusCode());
        }

        @Test
        @DisplayName("Should enforce status transition rules")
        void shouldEnforceStatusTransitionRules() {
            // Create an order
            CreateOrderRequest createRequest = new CreateOrderRequest("Test Customer", "Product", 1, new BigDecimal("50.00"));
            ResponseEntity<OrderResponse> createResponse = restTemplate.postForEntity(
                baseUrl, createRequest, OrderResponse.class
            );
            
            Long orderId = createResponse.getBody().getId();
            String statusUpdateUrl = baseUrl + "/" + orderId + "/status";

            // Try to skip from PENDING to SHIPPED (should fail)
            HttpEntity<String> invalidTransition = new HttpEntity<>("{\"status\": \"SHIPPED\"}");
            ResponseEntity<String> failedResponse = restTemplate.exchange(
                statusUpdateUrl, HttpMethod.PUT, invalidTransition, String.class
            );
            
            assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, failedResponse.getStatusCode());
        }
    }

    @Nested
    @DisplayName("API Operations E2E Tests")
    class ApiOperationsE2ETests {

        @Test
        @DisplayName("Should handle CRUD operations end-to-end")
        void shouldHandleCrudOperationsEndToEnd() {
            // Create multiple orders
            CreateOrderRequest request1 = new CreateOrderRequest("Alice Brown", "Monitor", 1, new BigDecimal("299.99"));
            CreateOrderRequest request2 = new CreateOrderRequest("Bob Wilson", "Keyboard", 2, new BigDecimal("75.00"));
            
            ResponseEntity<OrderResponse> response1 = restTemplate.postForEntity(baseUrl, request1, OrderResponse.class);
            ResponseEntity<OrderResponse> response2 = restTemplate.postForEntity(baseUrl, request2, OrderResponse.class);
            
            assertEquals(HttpStatus.CREATED, response1.getStatusCode());
            assertEquals(HttpStatus.CREATED, response2.getStatusCode());

            // Get all orders
            ResponseEntity<List<OrderResponse>> getAllResponse = restTemplate.exchange(
                baseUrl, HttpMethod.GET, null, new ParameterizedTypeReference<List<OrderResponse>>() {}
            );
            
            assertEquals(HttpStatus.OK, getAllResponse.getStatusCode());
            assertTrue(getAllResponse.getBody().size() >= 2);

            // Filter by customer
            String filterUrl = baseUrl + "?customerName=Alice%20Brown";
            ResponseEntity<List<OrderResponse>> filterResponse = restTemplate.exchange(
                filterUrl, HttpMethod.GET, null, new ParameterizedTypeReference<List<OrderResponse>>() {}
            );
            
            assertEquals(HttpStatus.OK, filterResponse.getStatusCode());
            assertEquals(1, filterResponse.getBody().size());
            assertEquals("Alice Brown", filterResponse.getBody().get(0).getCustomerName());

            // Get order statistics
            String statsUrl = baseUrl + "/stats/count?status=PENDING";
            ResponseEntity<String> statsResponse = restTemplate.getForEntity(statsUrl, String.class);
            
            assertEquals(HttpStatus.OK, statsResponse.getStatusCode());
            assertTrue(statsResponse.getBody().contains("\"status\":\"PENDING\""));

            // Delete an order
            Long orderIdToDelete = response1.getBody().getId();
            ResponseEntity<Void> deleteResponse = restTemplate.exchange(
                baseUrl + "/" + orderIdToDelete, HttpMethod.DELETE, null, Void.class
            );
            
            assertEquals(HttpStatus.NO_CONTENT, deleteResponse.getStatusCode());

            // Verify order is deleted
            ResponseEntity<String> getDeletedResponse = restTemplate.getForEntity(
                baseUrl + "/" + orderIdToDelete, String.class
            );
            
            assertEquals(HttpStatus.NOT_FOUND, getDeletedResponse.getStatusCode());
        }

        @SuppressWarnings("unchecked")
        @Test
        @DisplayName("Should handle concurrent order creation")
        void shouldHandleConcurrentOrderCreation() throws InterruptedException {
            int numberOfOrders = 10;
            Thread[] threads = new Thread[numberOfOrders];
            ResponseEntity<OrderResponse>[] responses = new ResponseEntity[numberOfOrders];

            // Create orders concurrently
            for (int i = 0; i < numberOfOrders; i++) {
                final int index = i;
                threads[i] = new Thread(() -> {
                    CreateOrderRequest request = new CreateOrderRequest(
                        "Customer " + index, "Product " + index, 1, new BigDecimal("10.00")
                    );
                    responses[index] = restTemplate.postForEntity(baseUrl, request, OrderResponse.class);
                });
                threads[i].start();
            }

            // Wait for all threads to complete
            for (Thread thread : threads) {
                thread.join();
            }

            // Verify all orders were created successfully
            for (ResponseEntity<OrderResponse> response : responses) {
                assertEquals(HttpStatus.CREATED, response.getStatusCode());
                assertNotNull(response.getBody().getId());
            }
        }
    }

    @Nested
    @DisplayName("Health and Monitoring E2E Tests")
    class HealthAndMonitoringE2ETests {

        @Test
        @DisplayName("Should provide health check endpoint")
        void shouldProvideHealthCheckEndpoint() {
            String healthUrl = "http://localhost:" + port + "/order-service/actuator/health";
            
            ResponseEntity<String> response = restTemplate.getForEntity(healthUrl, String.class);
            
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertTrue(response.getBody().contains("\"status\":\"UP\""));
        }

        @Test
        @DisplayName("Should handle error scenarios gracefully")
        void shouldHandleErrorScenariosGracefully() {
            // Test 404 for non-existent order
            ResponseEntity<String> notFoundResponse = restTemplate.getForEntity(
                baseUrl + "/99999", String.class
            );
            
            assertEquals(HttpStatus.NOT_FOUND, notFoundResponse.getStatusCode());
            assertTrue(notFoundResponse.getBody().contains("Order not found"));

            // Test malformed request
            ResponseEntity<String> badRequestResponse = restTemplate.postForEntity(
                baseUrl, "{\"invalid\": \"json\"}", String.class
            );
            
            assertEquals(HttpStatus.BAD_REQUEST, badRequestResponse.getStatusCode());
        }
    }
}
