package com.microservice.order.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.microservice.order.dto.CreateOrderRequest;
import com.microservice.order.dto.OrderResponse;
import com.microservice.order.entity.Order;
import com.microservice.order.entity.OrderStatus;
import com.microservice.order.exception.OrderNotFoundException;
import com.microservice.order.repository.OrderRepository;

@Service
@Transactional
public class OrderService {

    private final OrderRepository orderRepository;

    @Autowired
    public OrderService(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }

    public OrderResponse createOrder(CreateOrderRequest request) {
        // Apply business validation rules
        validateOrderRequest(request);
        
        Order order = new Order(
            request.getCustomerName(),
            request.getProductName(),
            request.getQuantity(),
            request.getPrice()
        );
        
        Order savedOrder = orderRepository.save(order);
        return mapToOrderResponse(savedOrder);
    }

    /**
     * Validates order creation with meaningful business rules.
     */
    private void validateOrderRequest(CreateOrderRequest request) {
        // Business rule: Minimum order quantity
        if (request.getQuantity() < 1) {
            throw new IllegalArgumentException("Order quantity must be at least 1");
        }
        
        // Business rule: Maximum order quantity per order
        if (request.getQuantity() > 1000) {
            throw new IllegalArgumentException("Order quantity cannot exceed 1000 items per order");
        }
        
        // Business rule: Minimum order value
        if (request.getPrice().doubleValue() < 0.01) {
            throw new IllegalArgumentException("Order price must be at least $0.01");
        }
        
        // Business rule: Maximum order value per single order
        if (request.getPrice().multiply(java.math.BigDecimal.valueOf(request.getQuantity())).doubleValue() > 100000.00) {
            throw new IllegalArgumentException("Total order value cannot exceed $100,000 per order");
        }
    }

    @Transactional(readOnly = true)
    public OrderResponse getOrderById(Long id) {
        Order order = orderRepository.findById(id)
            .orElseThrow(() -> new OrderNotFoundException("Order not found with id: " + id));
        return mapToOrderResponse(order);
    }

    @Transactional(readOnly = true)
    public List<OrderResponse> getAllOrders() {
        List<Order> orders = orderRepository.findAll();
        return orders.stream()
            .map(this::mapToOrderResponse)
            .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<OrderResponse> getOrdersByCustomer(String customerName) {
        List<Order> orders = orderRepository.findByCustomerName(customerName);
        return orders.stream()
            .map(this::mapToOrderResponse)
            .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<OrderResponse> getOrdersByStatus(OrderStatus status) {
        List<Order> orders = orderRepository.findByStatus(status);
        return orders.stream()
            .map(this::mapToOrderResponse)
            .collect(Collectors.toList());
    }

    public OrderResponse updateOrderStatus(Long id, OrderStatus newStatus) {
        Order order = orderRepository.findById(id)
            .orElseThrow(() -> new OrderNotFoundException("Order not found with id: " + id));
        
        // Apply business rules for status transitions
        validateStatusTransition(order.getStatus(), newStatus);
        
        order.setStatus(newStatus);
        Order updatedOrder = orderRepository.save(order);
        return mapToOrderResponse(updatedOrder);
    }

    /**
     * Validates business rules for order status transitions.
     * Implements meaningful business logic to ensure valid state transitions.
     */
    private void validateStatusTransition(OrderStatus currentStatus, OrderStatus newStatus) {
        // Once cancelled, order cannot be changed to any other status
        if (currentStatus == OrderStatus.CANCELLED) {
            throw new IllegalStateException("Cannot change status of a cancelled order");
        }
        
        // Once delivered, order cannot be changed (except to cancelled for returns)
        if (currentStatus == OrderStatus.DELIVERED && newStatus != OrderStatus.CANCELLED) {
            throw new IllegalStateException("Delivered orders can only be cancelled for returns");
        }
        
        // Cannot skip processing - orders must go through proper workflow
        if (currentStatus == OrderStatus.CONFIRMED && newStatus == OrderStatus.SHIPPED) {
            throw new IllegalStateException("Orders must be processed before shipping");
        }
        
        // Cannot ship pending orders - must be confirmed first
        if (currentStatus == OrderStatus.PENDING && 
            (newStatus == OrderStatus.PROCESSING || newStatus == OrderStatus.SHIPPED || newStatus == OrderStatus.DELIVERED)) {
            throw new IllegalStateException("Orders must be confirmed before processing, shipping, or delivery");
        }
        
        // Cannot deliver unshipped orders
        if (currentStatus != OrderStatus.SHIPPED && newStatus == OrderStatus.DELIVERED) {
            throw new IllegalStateException("Orders must be shipped before delivery");
        }
    }

    public void deleteOrder(Long id) {
        if (!orderRepository.existsById(id)) {
            throw new OrderNotFoundException("Order not found with id: " + id);
        }
        orderRepository.deleteById(id);
    }

    @Transactional(readOnly = true)
    public long getOrderCountByStatus(OrderStatus status) {
        return orderRepository.countByStatus(status);
    }

    private OrderResponse mapToOrderResponse(Order order) {
        return new OrderResponse(
            order.getId(),
            order.getCustomerName(),
            order.getProductName(),
            order.getQuantity(),
            order.getPrice(),
            order.getTotalAmount(),
            order.getStatus(),
            order.getCreatedAt(),
            order.getUpdatedAt()
        );
    }
}
