-- Sample data for testing
INSERT INTO orders (customer_name, product_name, quantity, price, order_status, created_at, updated_at) VALUES
('John Doe', 'Laptop', 1, 999.99, 'PENDING', NOW(), NOW()),
('Jane Smith', 'Mouse', 2, 25.50, 'CONFIRMED', NOW(), NOW()),
('Bob Johnson', 'Keyboard', 1, 75.00, 'PROCESSING', NOW(), NOW()),
('Alice Brown', 'Monitor', 1, 299.99, 'SHIPPED', NOW(), NOW()),
('Charlie Wilson', 'Headphones', 1, 149.99, 'DELIVERED', NOW(), NOW());
